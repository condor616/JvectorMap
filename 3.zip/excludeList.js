var excludeCountries = [
  "LY",
  "SS",
  "TD",
  "NG",
  "ML",
  "GL"
];
	
var myCustomColors = {
	'LY': '#FFFFFF',
	'SS': '#FFFFFF',
	'TD': '#FFFFFF',
	'NG': '#FFFFFF',
	'ML': '#FFFFFF',
	'GL': '#FFFFFF'
};