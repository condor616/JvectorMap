var excludeCountries = [
  "LY",
  "SS",
  "TD",
  "NG",
  "ML",
  "GL"
];